#pragma once
#include <QMainWindow>
#include <QStackedWidget>
#include <QLabel>
#include <QTableWidget>
#include <QLineEdit>
#include <QTextEdit>
#include "services/ResearchService.h"
class MainWindow:public QMainWindow{
 Q_OBJECT
public: explicit MainWindow(QWidget*parent=nullptr);
private slots: void navigate(int page); void startScrape(); void saveScrape(); void exportScrapeJson(); void exportScrapeCsv(); void refreshReports(); void saveSettings(); void runAI();
private: QWidget* makeDashboard(); QWidget* makeResearch(); QWidget* makeCompetitors(); QWidget* makeScraping(); QWidget* makeAI(); QWidget* makeReports(); QWidget* makeSettings(); void showMessage(const QString&,bool error=false); void buildTable(QTableWidget*,const QStringList&);
 QStackedWidget* pages; QLabel* statusLabel; QLineEdit* urlInput; QTextEdit* scrapeOutput; QJsonObject lastScrape; ResearchService research; QLineEdit* aiKey; QLineEdit* aiEndpoint; QTableWidget* reportTable; QTableWidget* activityTable;
};
