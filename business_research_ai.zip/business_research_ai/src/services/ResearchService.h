#pragma once
#include <QObject>
#include <QJsonObject>
#include <QNetworkAccessManager>
class ResearchService : public QObject {
 Q_OBJECT
public: explicit ResearchService(QObject *parent=nullptr); void scrape(const QString &url);
signals: void completed(const QJsonObject &data); void failed(const QString &message); void status(const QString &message);
private: QNetworkAccessManager m_net; void fetch(const QUrl &url,int redirects=0);
};
