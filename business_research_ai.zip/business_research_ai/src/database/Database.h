#pragma once
#include <QSqlDatabase>
#include <QJsonObject>
class Database {
public:
 static Database &instance(); bool initialize(QString *error=nullptr); QSqlDatabase db() const { return m_db; }
 bool saveReport(const QString &name,const QString &type,const QString &subject,const QJsonObject &data,QString *error=nullptr);
 bool logActivity(const QString &name,const QString &type,const QString &status,const QString &detail={});
private: Database()=default; QSqlDatabase m_db;
};
