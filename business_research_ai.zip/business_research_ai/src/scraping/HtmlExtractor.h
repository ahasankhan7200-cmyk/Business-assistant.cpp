#pragma once
#include <QString>
#include <QStringList>
#include <QJsonObject>
namespace HtmlExtractor { QJsonObject extract(const QByteArray &html, const QString &url); }
