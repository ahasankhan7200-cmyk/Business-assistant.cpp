# Business Research AI (C++ / Qt 6)

A native desktop research workspace built with C++17, Qt 6 Widgets, Qt Network, Qt SQL/SQLite, and CMake. This repository is an **initial functional implementation**, not a claim that every item in the master specification is complete. It has a navigable desktop UI, SQLite persistence, public HTML retrieval/parsing, JSON/CSV exports for scraped pages, report persistence, and core tests. Search-provider integration, production-grade SSRF hardening, complete competitor/market workflows, AI transport, PDF/XLSX exports, and OS keychain integration remain incomplete.

## Features implemented

- Qt desktop shell with the seven requested navigation sections and dark navy sidebar.
- SQLite schema initialization for companies, queries, results, scraped pages, competitors, comparisons, market research, AI analyses, saved reports, settings, and activity logs.
- Public HTTP(S) HTML fetch with timeout, 4 MB limit, manual redirect handling, and URL checks for unsafe schemes, localhost, and common private/reserved literal IP ranges.
- HTML title, description, headings, visible text, source URL, and retrieval timestamp extraction.
- Saved reports persist in SQLite and can be viewed/deleted from the Saved Reports screen.
- JSON and CSV export for the latest scraped page.
- Basic automated tests for URL validation and HTML extraction.
- Configurable AI endpoint/key settings UI; **AI request transport is not implemented** and the UI explicitly reports that limitation.

## Not implemented yet

- Real web search-provider adapters (therefore company search does not produce online search results).
- Competitor discovery, sourced pricing/feature comparisons, and market-data collection.
- Working LLM integration, generated SWOT reports, citations pipeline.
- PDF/XLSX export, pagination, cancellation/progress UI, robots.txt enforcement, cache management, multilingual UI, secure OS keychain storage.
- Fully hardened SSRF defense: DNS rebinding and address pinning need a stronger transport layer or OS/network egress policy. Do not expose this app as a public scraping service.

No fake research results are inserted. The app does not bypass authentication, paywalls, CAPTCHAs, or anti-bot measures. Before scraping a site, check its terms and robots.txt. The current code does **not yet implement robots.txt checking**, so use only pages you are permitted to retrieve.

## Dependencies

- C++17 compiler (GCC 11+, Clang 14+, or MSVC 2022 recommended)
- CMake 3.21+
- Qt 6.4+ modules: Widgets, Network, Sql, Concurrent, Test
- SQLite driver plugin supplied by the Qt distribution (`QSQLITE`)

## Build on Ubuntu 24.04 / Debian-based Linux

```bash
sudo apt update
sudo apt install build-essential cmake qt6-base-dev qt6-base-dev-tools libqt6sql6-sqlite
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build -j2
ctest --test-dir build --output-on-failure
./build/business_research_ai
```

Qt package names vary by distribution. On Windows, install Qt 6.4+ with Qt Online Installer (including Qt Widgets, Network, SQL, Concurrent, and Qt Test), install CMake and Visual Studio 2022 C++ workload, then configure using the Qt kit's CMake toolchain/environment. Example from a Qt-enabled developer shell:

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/msvc2022_64" -DBUILD_TESTING=ON
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

## Database and settings

SQLite database is created under `QStandardPaths::AppDataLocation` as `research.sqlite`. On Linux this is normally under `~/.local/share/BusinessResearchAI/Business Research AI/` (exact path depends on Qt/desktop environment). Settings use Qt `QSettings`. The API key field is masked in the UI, but currently stored in ordinary local settings, **not an OS keychain**. For production use, replace with Windows Credential Manager, macOS Keychain, or a Linux Secret Service integration.

## Search and AI configuration status

The Settings screen lets you save an AI-compatible endpoint and API key, but AI calls are deliberately not made because the request/response implementation and source-grounding pipeline are not yet complete. Business Research records a query as pending provider configuration rather than claiming that a search happened. Add a documented provider adapter (e.g. a vendor-supported search API) before enabling live search. Provider APIs may require credentials and may incur costs.

## Security notes

The URL guard blocks non-HTTP schemes, localhost/local hostnames, and common private/reserved literal IP ranges. The scraper revalidates redirects and caps response size and duration. This is defense-in-depth, not a complete SSRF guarantee: hostname DNS is resolved separately from the HTTP connection, so DNS rebinding is possible. For untrusted input, run scraping in a restricted network sandbox with outbound firewall rules and DNS/IP pinning. Robots.txt, content licensing, and terms compliance need to be added before broad deployment.

## Tests

Tests are defined in `tests/test_core.cpp`. They cover URL scheme/localhost/public URL checks and basic HTML metadata extraction. Test execution results must be reported only after actually building and running `ctest` on a machine with Qt 6 installed.

## Distribution

This is a desktop Qt application; it does not run as a GitHub Pages site. Distribute platform-specific binaries with the required Qt runtime dependencies (e.g. Qt deployment tools), or build a separate web frontend and a secured backend if browser access is required.
