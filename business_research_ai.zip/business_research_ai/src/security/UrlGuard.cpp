#include "UrlGuard.h"
#include <QUrl>
#include <QHostAddress>
#include <QRegularExpression>
namespace {
bool privateAddress(const QHostAddress &a) {
 if (a.protocol()==QAbstractSocket::IPv4Protocol) {
  quint32 x=a.toIPv4Address();
  return (x>>24)==10 || (x>>24)==127 || (x>>24)==0 || (x>>16)==0xA9FE ||
         (x>>20)==0xAC1 || (x>>16)==0xC0A8 || (x>>16)==0x644 || (x>>24)>=224;
 }
 if (a.protocol()==QAbstractSocket::IPv6Protocol) {
  return a.isLoopback() || a.isLinkLocal() || a.isUniqueLocalUnicast() || a.isNull();
 }
 return true;
}
}
bool UrlGuard::isPublicAddress(const QHostAddress &address) { return !privateAddress(address); }
bool UrlGuard::validatePublicHttpUrl(const QString &input, QString *error) {
 auto fail=[&](const QString &s){if(error)*error=s; return false;};
 QUrl u=QUrl::fromUserInput(input.trimmed());
 if (!u.isValid() || (u.scheme()!="http" && u.scheme()!="https")) return fail("Only valid http:// or https:// URLs are supported.");
 if (u.host().isEmpty() || !u.userInfo().isEmpty()) return fail("URL must have a host and must not contain embedded credentials.");
 QString host=u.host().toLower();
 if (host=="localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host=="metadata.google.internal") return fail("Local and metadata hosts are blocked.");
 QHostAddress addr;
 if (addr.setAddress(host) && privateAddress(addr)) return fail("Private, loopback, link-local, and reserved IP addresses are blocked.");
 if (host.contains(QRegularExpression("[^a-z0-9.:-]"))) return fail("Invalid hostname.");
 return true;
}
