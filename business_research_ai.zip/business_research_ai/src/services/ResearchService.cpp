#include "ResearchService.h"
#include "security/UrlGuard.h"
#include "scraping/HtmlExtractor.h"
#include "database/Database.h"
#include <QNetworkReply>
#include <QHostInfo>
#include <QNetworkRequest>
#include <QTimer>
#include <QJsonDocument>
#include <QSqlQuery>
#include <QSqlError>
ResearchService::ResearchService(QObject *p):QObject(p){m_net.setRedirectPolicy(QNetworkRequest::ManualRedirectPolicy);}
void ResearchService::scrape(const QString &s){QString e;QUrl u=QUrl::fromUserInput(s.trimmed());if(!UrlGuard::validatePublicHttpUrl(s,&e)){emit failed(e);return;}fetch(u,0);}
void ResearchService::fetch(const QUrl &url,int redirects){
 if(redirects>5){emit failed("Too many redirects.");return;} QString err;if(!UrlGuard::validatePublicHttpUrl(url.toString(),&err)){emit failed(err);return;}
 // DNS resolution is checked before requesting. Redirect targets are revalidated. For high-assurance deployment,
 // enforce DNS pinning / egress firewalling too, because DNS can change between lookup and connect.
 auto addresses=QHostInfo::fromName(url.host()).addresses(); if(addresses.isEmpty()){emit failed("Host could not be resolved.");return;}
 for(const auto &a:addresses){if(!UrlGuard::isPublicAddress(a)){emit failed("Host resolves to a private, loopback, link-local, or reserved address.");return;}}
 QNetworkRequest req(url);req.setHeader(QNetworkRequest::UserAgentHeader,"BusinessResearchAI/0.1 (public research; contact: administrator)");req.setTransferTimeout(12000);req.setAttribute(QNetworkRequest::RedirectPolicyAttribute,QNetworkRequest::ManualRedirectPolicy);
 QNetworkReply *r=m_net.get(req); QTimer *timer=new QTimer(r);timer->setSingleShot(true);connect(timer,&QTimer::timeout,r,[r]{r->abort();});timer->start(15000);
 connect(r,&QNetworkReply::finished,this,[this,r,url,redirects,timer](){timer->stop();QVariant red=r->attribute(QNetworkRequest::RedirectionTargetAttribute);if(red.isValid()){QUrl next=url.resolved(red.toUrl());r->deleteLater();fetch(next,redirects+1);return;}if(r->error()!=QNetworkReply::NoError){emit failed("Request failed: "+r->errorString());r->deleteLater();return;}QByteArray body=r->read(4*1024*1024+1);QVariant ct=r->header(QNetworkRequest::ContentTypeHeader);r->deleteLater();if(body.size()>4*1024*1024){emit failed("Page exceeds the 4 MB response limit.");return;}if(!ct.toString().contains("text/html",Qt::CaseInsensitive)){emit failed("Unsupported content type. Only HTML pages are parsed.");return;}QJsonObject data=HtmlExtractor::extract(body,url.toString());QSqlQuery q(Database::instance().db());q.prepare("INSERT INTO scraped_pages(url,title,description,content_json,retrieved_at) VALUES(?,?,?,?,?)");q.addBindValue(url.toString());q.addBindValue(data.value("title").toString());q.addBindValue(data.value("description").toString());q.addBindValue(QString::fromUtf8(QJsonDocument(data).toJson(QJsonDocument::Compact)));q.addBindValue(data.value("retrieved_at").toString());if(!q.exec())emit status("Retrieved page; database save failed: "+q.lastError().text());else Database::instance().logActivity(url.toString(),"Web scraping","Complete");emit completed(data);});
}
