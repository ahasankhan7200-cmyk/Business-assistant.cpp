#include "Exporter.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QTextStream>
static QString csvCell(QString s){s.replace("\"","\"\"");return "\""+s+"\"";}
bool Exporter::json(const QJsonObject&o,const QString&p,QString*e){QFile f(p);if(!f.open(QIODevice::WriteOnly|QIODevice::Truncate)){if(e)*e=f.errorString();return false;}f.write(QJsonDocument(o).toJson(QJsonDocument::Indented));return true;}
bool Exporter::csv(const QJsonObject&o,const QString&p,QString*e){QFile f(p);if(!f.open(QIODevice::WriteOnly|QIODevice::Truncate|QIODevice::Text)){if(e)*e=f.errorString();return false;}QTextStream t(&f);t<<"field,value\n";for(auto it=o.begin();it!=o.end();++it){QString v;if(it.value().isString())v=it.value().toString();else if(it.value().isArray()||it.value().isObject())v=QString::fromUtf8(QJsonDocument(it.value().isObject()?it.value().toObject():QJsonObject{{"items",it.value()}}).toJson(QJsonDocument::Compact));else v=it.value().toVariant().toString();t<<csvCell(it.key())<<","<<csvCell(v)<<"\n";}return true;}
