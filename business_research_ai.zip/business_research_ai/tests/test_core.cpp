#include <QtTest>
#include "security/UrlGuard.h"
#include "scraping/HtmlExtractor.h"
class CoreTests:public QObject{Q_OBJECT
private slots:
 void rejectsUnsafeSchemes(){QString e;QVERIFY(!UrlGuard::validatePublicHttpUrl("file:///etc/passwd",&e));QVERIFY(!e.isEmpty());}
 void rejectsLocalhost(){QVERIFY(!UrlGuard::validatePublicHttpUrl("http://localhost/admin"));QVERIFY(!UrlGuard::validatePublicHttpUrl("http://127.0.0.1/"));}
 void acceptsPublicUrl(){QVERIFY(UrlGuard::validatePublicHttpUrl("https://example.com/about"));}
 void extractsMetadata(){auto o=HtmlExtractor::extract("<html><head><title>Acme</title><meta name=\"description\" content=\"A company\"></head><body><h1>Products</h1><p>Public text</p></body></html>","https://example.com");QCOMPARE(o.value("title").toString(),QString("Acme"));QVERIFY(o.value("headings").toArray().size()==1);QVERIFY(o.value("text").toString().contains("Public text"));}
};
QTEST_MAIN(CoreTests)
#include "test_core.moc"
