#pragma once
#include <QString>
#include <QHostAddress>
namespace UrlGuard {
// Rejects unsafe schemes, localhost, literal private IPs, and local hostnames.
bool validatePublicHttpUrl(const QString &input, QString *error = nullptr);
bool isPublicAddress(const QHostAddress &address);
}
