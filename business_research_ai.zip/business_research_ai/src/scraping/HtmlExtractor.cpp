#include "HtmlExtractor.h"
#include <QRegularExpression>
#include <QJsonArray>
#include <QTextDocument>
#include <QDateTime>
static QString clean(QString s) { s.replace(QRegularExpression("<script\\b[^>]*>[\\s\\S]*?</script>", QRegularExpression::CaseInsensitiveOption), " "); s.replace(QRegularExpression("<style\\b[^>]*>[\\s\\S]*?</style>", QRegularExpression::CaseInsensitiveOption), " "); QTextDocument d; d.setHtml(s); return d.toPlainText().simplified(); }
static QString tagContent(const QString &h, const QString &tag) { QRegularExpression re("<"+tag+"\\b[^>]*>([\\s\\S]*?)</"+tag+"\\s*>", QRegularExpression::CaseInsensitiveOption); auto m=re.match(h); return m.hasMatch()?clean(m.captured(1)):QString(); }
QJsonObject HtmlExtractor::extract(const QByteArray &bytes, const QString &url) {
 QString h=QString::fromUtf8(bytes); QJsonObject o; o["source_url"]=url;
 QRegularExpression titleRe("<title\\b[^>]*>([\\s\\S]*?)</title\\s*>",QRegularExpression::CaseInsensitiveOption); auto tm=titleRe.match(h); o["title"]=tm.hasMatch()?clean(tm.captured(1)):QString();
 QRegularExpression descRe("<meta\\b(?=[^>]*name=['\"]description['\"])(?=[^>]*content=['\"]([^'\"]*)['\"])[^>]*>",QRegularExpression::CaseInsensitiveOption); auto dm=descRe.match(h); o["description"]=dm.hasMatch()?dm.captured(1):QString();
 QJsonArray heads; QRegularExpression hr("<h[1-6]\\b[^>]*>([\\s\\S]*?)</h[1-6]\\s*>",QRegularExpression::CaseInsensitiveOption); auto it=hr.globalMatch(h); while(it.hasNext() && heads.size()<100) { auto m=it.next(); QString s=clean(m.captured(1)); if(!s.isEmpty()) heads.append(s); } o["headings"]=heads;
 QString text=clean(h); o["text"]=text.left(40000); o["retrieved_at"]=QDateTime::currentDateTimeUtc().toString(Qt::ISODate); return o;
}
