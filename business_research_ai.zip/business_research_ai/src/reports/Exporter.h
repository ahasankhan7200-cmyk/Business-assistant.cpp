#pragma once
#include <QJsonObject>
#include <QString>
namespace Exporter { bool json(const QJsonObject&,const QString&,QString*error=nullptr); bool csv(const QJsonObject&,const QString&,QString*error=nullptr); }
