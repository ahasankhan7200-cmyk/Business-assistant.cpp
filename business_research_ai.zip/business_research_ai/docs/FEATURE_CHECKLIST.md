# Feature checklist

| Requirement | Status | Notes |
|---|---|---|
| C++17 / Qt Widgets / CMake | Implemented | Native application shell |
| Sidebar with 7 navigation items | Implemented | Text navigation, responsive window resizing |
| SQLite persistence / versioned schema | Partial | Core tables and schema version row; migrations need expansion |
| Research history | Partial | Query and activity logging; live provider absent |
| Search-provider adapters | Not implemented | Must add supported API adapter and credential handling |
| Public webpage retrieval | Partial | HTML only, limits and redirect checks; robots.txt missing |
| HTML metadata / headings / text extraction | Implemented | Basic parser using Qt QTextDocument and regular expressions |
| Company profiles | Partial | Schema and query workspace; no live discovery |
| Competitor analysis | Partial | Workspace and report persistence only, no evidence-backed comparison engine |
| Market research | Not implemented | Schema only |
| AI SWOT / insights / recommendations | Not implemented | Settings UI only; AI transport explicitly disabled |
| Saved reports / persistence | Implemented | SQLite list, view, delete with confirmation |
| JSON / CSV exports | Implemented | Latest scraped page; general report export still partial |
| PDF / Excel export | Not implemented | Add Qt-compatible PDF/XLSX libraries |
| Settings / masked API key | Partial | QSettings; no OS keychain |
| Security controls | Partial | URL checks and limits; DNS rebinding/robots.txt protections incomplete |
| Automated tests | Partial | Core URL and HTML extraction tests written; execution depends on Qt availability |
| Screenshot-faithful UI | Partial | Screenshot was not attached to the request, so layout follows written description |
