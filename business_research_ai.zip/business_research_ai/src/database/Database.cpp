#include "Database.h"
#include <QStandardPaths>
#include <QDir>
#include <QSqlQuery>
#include <QSqlError>
#include <QJsonDocument>
Database &Database::instance(){static Database d; return d;}
bool Database::initialize(QString *error){
 QString path=QStandardPaths::writableLocation(QStandardPaths::AppDataLocation); QDir().mkpath(path);
 if(!m_db.isValid()){m_db=QSqlDatabase::addDatabase("QSQLITE");m_db.setDatabaseName(path+"/research.sqlite");}
 if(!m_db.open()){if(error)*error=m_db.lastError().text();return false;}
 QSqlQuery q(m_db); QStringList sql={
 "PRAGMA foreign_keys=ON",
 "CREATE TABLE IF NOT EXISTS schema_version(version INTEGER NOT NULL)",
 "CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY, name TEXT NOT NULL, website TEXT, description TEXT, source_url TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS research_queries(id INTEGER PRIMARY KEY, query TEXT NOT NULL, type TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS search_results(id INTEGER PRIMARY KEY, query_id INTEGER, title TEXT, url TEXT, description TEXT, provider TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(query_id) REFERENCES research_queries(id))",
 "CREATE TABLE IF NOT EXISTS scraped_pages(id INTEGER PRIMARY KEY, url TEXT NOT NULL, title TEXT, description TEXT, content_json TEXT, retrieved_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS competitors(id INTEGER PRIMARY KEY, company_id INTEGER, name TEXT NOT NULL, website TEXT, evidence_json TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(company_id) REFERENCES companies(id))",
 "CREATE TABLE IF NOT EXISTS competitor_comparisons(id INTEGER PRIMARY KEY, subject TEXT, data_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS market_research(id INTEGER PRIMARY KEY, subject TEXT, data_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS ai_analyses(id INTEGER PRIMARY KEY, subject TEXT, provider TEXT, data_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS saved_reports(id INTEGER PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL, subject TEXT, status TEXT NOT NULL DEFAULT 'Complete', data_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
 "CREATE TABLE IF NOT EXISTS application_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)",
 "CREATE TABLE IF NOT EXISTS activity_logs(id INTEGER PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL, status TEXT NOT NULL, detail TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
 "CREATE INDEX IF NOT EXISTS idx_reports_created ON saved_reports(created_at DESC)", "CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_logs(created_at DESC)"};
 for(const auto &s:sql) if(!q.exec(s)){if(error)*error=q.lastError().text();return false;}
 q.exec("SELECT COUNT(*) FROM schema_version"); if(q.next()&&q.value(0).toInt()==0) q.exec("INSERT INTO schema_version(version) VALUES(1)"); return true;
}
bool Database::saveReport(const QString &name,const QString &type,const QString &subject,const QJsonObject &data,QString *error){QSqlQuery q(m_db);q.prepare("INSERT INTO saved_reports(name,type,subject,status,data_json) VALUES(?,?,?,'Complete',?)");q.addBindValue(name);q.addBindValue(type);q.addBindValue(subject);q.addBindValue(QString::fromUtf8(QJsonDocument(data).toJson(QJsonDocument::Compact)));if(!q.exec()){if(error)*error=q.lastError().text();return false;}logActivity(name,type,"Complete");return true;}
bool Database::logActivity(const QString &name,const QString &type,const QString &status,const QString &detail){QSqlQuery q(m_db);q.prepare("INSERT INTO activity_logs(name,type,status,detail) VALUES(?,?,?,?)");q.addBindValue(name);q.addBindValue(type);q.addBindValue(status);q.addBindValue(detail);return q.exec();}
