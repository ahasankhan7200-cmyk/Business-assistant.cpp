#include "app/MainWindow.h"
#include <QApplication>
#include <QStandardPaths>
#include <QDir>
int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    QApplication::setApplicationName("Business Research AI");
    QApplication::setOrganizationName("BusinessResearchAI");
    QDir().mkpath(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation));
    MainWindow window; window.show();
    return app.exec();
}
